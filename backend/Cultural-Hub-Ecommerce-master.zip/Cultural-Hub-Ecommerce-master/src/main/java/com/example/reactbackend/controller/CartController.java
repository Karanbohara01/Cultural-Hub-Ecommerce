//package com.example.reactbackend.controller;
//
//
//import com.example.reactbackend.entity.Cart;
//import com.example.reactbackend.pojo.CartPojo;
//import com.example.reactbackend.service.CartService;
//import jakarta.validation.Valid;
//import lombok.RequiredArgsConstructor;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//import org.springframework.web.multipart.MultipartFile;
//
//
//import java.io.IOException;
//import java.util.List;
//import java.util.Optional;
//
//@RestController
//@RequestMapping("/user/add/cart")
//@RequiredArgsConstructor
//@CrossOrigin("*")
//public class CartController {
//
//    private final CartService cartService;
//
//
//    @PostMapping(value = "/save")
//    public String addToCart(@RequestBody @ModelAttribute CartPojo cartPojo) throws IOException {
//        cartService.save(cartPojo);
//        return "Saved Successfully!";
//    }
//
////    @PostMapping("/upload")
////    public ResponseEntity<String> uploadFile(@RequestBody FileUploadDTO fileUploadDTO) {
////        // Process the file content from fileUploadDTO.getFileContent()
////        // ...
////        return ResponseEntity.ok("File uploaded successfully");
////    }
//
//
//    @GetMapping("/getAll")
//    public List<Cart> getAll() {
//        return this.cartService.getAll();
//
//
//    }
//    @GetMapping("/getById/{id}")
//    public Optional<Cart> getById(@PathVariable("id") Long id) {
//        return this.cartService.getById(id);
//    }
//
//
//    @DeleteMapping("/delete/{id}")
//    public void deleteById(@PathVariable("id") Long id) {
//        this.cartService.deleteById(id);
//    }
//
//
////    @PutMapping("/update/{id}")
////    public String updateCart(@PathVariable("id") Long id, @Valid @RequestBody CartPojo cartPojo) {
////        return this.cartService.update(id, cartPojo);
////    }
//
//    @PutMapping("update/{id}")
//    public ResponseEntity<String> updateCart(@PathVariable Long id,
//                                             @RequestParam("productName") String productName,
//                                             @RequestParam("productPrice") Integer productPrice,
//                                             @RequestParam("productDescription") String productDescription,
//                                             @RequestParam("brandName") String brandName,
//                                             @RequestParam("image") MultipartFile image) {
//        // Your update logic here
//        return ResponseEntity.ok("Cart updated successfully");
//    }
//
//
//
//
//
//}


package com.example.reactbackend.controller;

import com.example.reactbackend.entity.Cart;
import com.example.reactbackend.pojo.CartPojo;
import com.example.reactbackend.service.CartService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/user/add/cart")
@RequiredArgsConstructor
@CrossOrigin("*")
public class CartController {

    private final CartService cartService;

    @PostMapping("/save")
    public String addToCart(@RequestBody @ModelAttribute CartPojo cartPojo) throws IOException {
        cartService.save(cartPojo);
        return "Saved Successfully!";
    }

    @GetMapping("/getAll")
    public List<Cart> getAll() {
        return cartService.getAll();
    }

    @GetMapping("/getById/{id}")
    public Optional<Cart> getById(@PathVariable("id") Long id) {
        return cartService.getById(id);
    }

    @DeleteMapping("/delete/{id}")
    public void deleteById(@PathVariable("id") Long id) {
        cartService.deleteById(id);
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<String> updateCart(@PathVariable Long id,
                                             @RequestParam("productName") String productName,
                                             @RequestParam("productPrice") Integer productPrice,
                                             @RequestParam("productDescription") String productDescription,
                                             @RequestParam("brandName") String brandName,
                                             @RequestParam("image") MultipartFile image) {
        // Your update logic here
        CartPojo cartPojo = new CartPojo();
        cartPojo.setProductName(productName);
        cartPojo.setProductPrice(productPrice);
        cartPojo.setProductDescription(productDescription);
        cartPojo.setBrandName(brandName);
        cartPojo.setImage(image);  // Assuming CartPojo has a setImage method for MultipartFile

        try {
            cartService.update(id, cartPojo);
            return ResponseEntity.ok("Cart updated successfully");
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error updating cart: " + e.getMessage());
        }
    }
}
