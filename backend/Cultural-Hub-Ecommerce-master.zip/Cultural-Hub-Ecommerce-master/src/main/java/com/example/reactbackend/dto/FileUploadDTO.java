package com.example.reactbackend.dto;

public class FileUploadDTO {
    private String fileName;
    private byte[] fileContent;
}
