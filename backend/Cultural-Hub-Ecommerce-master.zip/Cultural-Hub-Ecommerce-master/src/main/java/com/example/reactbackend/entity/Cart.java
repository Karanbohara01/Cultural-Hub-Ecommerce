package com.example.reactbackend.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Table(name = "cart")
@Entity


public class Cart {
    @Id
    @SequenceGenerator(name = "cart_seq_gen", sequenceName = "cart_id_seq", allocationSize = 1)
    @GeneratedValue(generator = "cart_seq_gen", strategy = GenerationType.SEQUENCE)
    private Long cartId;
    @Column(name = "product_name")
    private String productName;
    @Column(name = "brand_name")
    private String brandName;
    @Column(name = "product_price")
    private double productPrice;
    @Column (name = "productDescription")
    private  String productDescription;
    private String image;
    @Column(name = "tatal_price")
    private double totalPrice;
}
