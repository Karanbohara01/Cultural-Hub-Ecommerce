package com.example.reactbackend.pojo;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.web.multipart.MultipartFile;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CartPojo {
    private Long cartId;
    private String productName;
    private int productPrice; // Changed from Integer to int
    private String productDescription;
    private int totalPrice; // Changed from Integer to int
    private String brandName;

    @NotEmpty(message = "Image is required")
    private MultipartFile image;
}
