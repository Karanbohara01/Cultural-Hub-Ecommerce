package com.example.reactbackend.service;

import com.example.reactbackend.entity.Cart;
import com.example.reactbackend.pojo.CartPojo;
import org.springframework.stereotype.Service;


import java.io.IOException;
import java.util.List;
import java.util.Optional;
@Service

public interface CartService {

    String save(CartPojo cartPojo) throws IOException;
    List<Cart> getAll();
    void deleteById(Long id);
    Optional<Cart> getById(Long id);
    String update(Long id, CartPojo cartPojo);
}
