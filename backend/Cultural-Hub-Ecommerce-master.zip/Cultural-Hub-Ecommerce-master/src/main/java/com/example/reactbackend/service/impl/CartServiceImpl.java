package com.example.reactbackend.service.impl;

import com.example.reactbackend.entity.Cart;
import com.example.reactbackend.pojo.CartPojo;
import com.example.reactbackend.repo.CartRepo;
import com.example.reactbackend.service.CartService;
import com.example.reactbackend.utils.ImageToBase64;
import jakarta.persistence.EntityNotFoundException;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor

public class CartServiceImpl implements CartService {
    private final CartRepo cartRepo;
    ImageToBase64 imageToBase64 = new ImageToBase64();

    @Override
    public String save(CartPojo cartPojo) throws IOException {
        Cart cart;
        if (cartPojo.getCartId() != null) {
            cart = cartRepo.findById(cartPojo.getCartId())
                    .orElseThrow(() -> new EntityNotFoundException("Product not found with ID " + cartPojo.getCartId()));
        } else {
            cart = new Cart();
        }
        cart.setProductName(cartPojo.getProductName());
        cart.setTotalPrice(cartPojo.getTotalPrice());
        cart.setBrandName(cartPojo.getBrandName());
        cart.setProductPrice(cartPojo.getProductPrice());
        cart.setProductDescription(cartPojo.getProductDescription());

        if (cartPojo.getImage() != null && cartPojo.getImage().getOriginalFilename() != null ) {
            Path fileNameAndPath = Paths.get("C:\\Users\\Acer\\OneDrive\\Desktop\\app/file/", cartPojo.getImage().getOriginalFilename());
            Files.write(fileNameAndPath, cartPojo.getImage().getBytes());
        }
        cart.setImage(cartPojo.getImage().getOriginalFilename());
        cartRepo.save(cart);
        return "Saved Successfully";
    }

    @Override
    public List<Cart> getAll() {
        return cartRepo.findAll().stream().map(item -> {
            item.setImage(imageToBase64.getImageBase64(item.getImage()));
            return item;
        }).collect(Collectors.toList());
    }

    @Override
    public void deleteById(Long id) {
        cartRepo.deleteById(id);
    }

    @Override
    public Optional<Cart> getById(Long id) {
        return cartRepo.findById(id);
    }

    @Override
    public String update(Long id, CartPojo cartPojo) {
        Cart existingCart = cartRepo.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Product not found with ID: " + id));

        existingCart.setProductName(cartPojo.getProductName());
        existingCart.setProductDescription(cartPojo.getProductDescription());
        existingCart.setProductPrice(cartPojo.getProductPrice());
        existingCart.setTotalPrice(cartPojo.getTotalPrice());


        cartRepo.save(existingCart);
        return "Updated Successfully!";
    }





}

