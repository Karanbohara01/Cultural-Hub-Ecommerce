package com.example.reactbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
